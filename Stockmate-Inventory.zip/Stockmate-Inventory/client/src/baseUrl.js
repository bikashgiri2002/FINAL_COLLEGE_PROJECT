const baseUrl ="http://localhost:4000"

export default baseUrl;